import {
  GetServerSideProps,
  GetServerSidePropsContext,
  GetStaticPropsContext,
  NextPage,
} from "next";
import { NextRouter, useRouter } from "next/router";
import { useEffect, useState } from "react";
import { useQuery } from "react-query";

const getMovieDetail = async (id: string): Promise<any> => {
  const data = await fetch(
    `https://api.themoviedb.org/3/movie/${id}?api_key=575fe42afb99519dca44ad51c337b911&language=en-US`
  );
  return data.json();
};

const MovieDetail: NextPage = (props) => {
  const { data } = props;
  return (
    <>
      <div>{data.title}</div>
      <div>{data.overview}</div>
      <div>{data.original_title}</div>
    </>
  );
};

export async function getStaticPaths() {
  const response = await fetch(
    "https://api.themoviedb.org/3/movie/popular?api_key=575fe42afb99519dca44ad51c337b911&language=en-US&page=1"
  );
  const data = await response.json();
  console.log(data);
  const paths = data.results.map((item: any) => {
    return {
      params: { id: item.id.toString() },
    };
  });

  return {
    paths: paths,
    fallback: true, // false or 'blocking'
  };
}

export const getStaticProps = async (context: GetStaticPropsContext) => {
  const id = context.params?.id;
  const response = await fetch(
    `https://api.themoviedb.org/3/movie/${id}?api_key=575fe42afb99519dca44ad51c337b911&language=en-US`
  );

  const data = await response.json();
  console.log(data);
  return {
    props: {
      data: data,
    },
  };
};
export default MovieDetail;
