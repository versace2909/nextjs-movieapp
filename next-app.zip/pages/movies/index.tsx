import { NextPage } from "next";
import Link from "next/link";
import { useQuery } from "react-query";
import styles from "../../styles/Movies.module.css";

const getMovies = async (): Promise<any> => {
  const fetchData = await fetch(
    "https://api.themoviedb.org/3/movie/popular?api_key=575fe42afb99519dca44ad51c337b911&language=en-US&page=1"
  );
  return fetchData.json();
};

const MoviePage: NextPage = () => {
  const { data, isError, isLoading, isSuccess } = useQuery(
    "getmovies",
    getMovies
  );

  return (
    <>
      {isError && <div>Could not fetch data...</div>}
      {isLoading && <div>Loading...</div>}
      {isSuccess && (
        <div className={styles.movies}>
          {data.results.map((movie: any) => {
            const divStyle = {
              backgroundImage: `url(https://image.tmdb.org/t/p/original${movie.poster_path})`,
              backgroundSize: "cover",
            };
            return (
              <Link key={movie.id} href={`/movies/${movie.id}`}>
                <a className={styles["movie-item"]} key={movie.id}>
                  <div
                    style={divStyle}
                    className={styles["movie-item-content"]}
                  >
                    <div className={styles.overlay}>
                      <h2>{movie.original_title}</h2>
                      <p>Release date: {movie.release_date}</p>
                    </div>
                  </div>
                </a>
              </Link>
            );
          })}
        </div>
      )}
    </>
  );
};
export default MoviePage;
